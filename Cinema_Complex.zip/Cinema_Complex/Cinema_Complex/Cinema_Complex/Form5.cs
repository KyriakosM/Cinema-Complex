﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace Cinema_Complex
{
    public partial class Form5 : Form
    {
        string[] postgres = new string[6] { "", "", "", "", "", "" };
        int[] timi = new int[6] { 0, 0, 0, 0, 0, 0 };
        public Form5()
        {
            InitializeComponent();


            /////read from db
            var connString = "Host=localhost;Username=postgres;Password=9755;Database=myUsers";
            var conn = new NpgsqlConnection(connString);
            conn.Open();
            var cmd = new NpgsqlCommand("select seat from bookings", conn);
            var reader = cmd.ExecuteReader();
            string[] myArr = new string[6] { "", "", "", "", "", "" };
            //counter
            int x = 0;
            while (reader.Read())
            {
                //Console.WriteLine("{0}", reader[0]);
                myArr[x] = reader[0].ToString();
                //increment counter
                x++;
            }
            
            conn.Close();
            //////////////
            for (int n = 0; n < myArr.Length; n++)
            {
                if (!myArr[n].Equals(""))
                {
                    if (myArr[n].Equals("A1"))
                    {
                        //check for reserved seat
                        button1.BackColor = Color.Red; 
                        button1.Enabled = false;
                    }
                    else if (myArr[n].Equals("A2"))
                    {
                        button2.BackColor = Color.Red; 
                        button2.Enabled = false;
                    }
                    else if (myArr[n].Equals("A3"))
                    {
                        button3.BackColor = Color.Red; 
                        button3.Enabled = false;
                    }
                    else if (myArr[n].Equals("B1"))
                    {
                        button4.BackColor = Color.Red; 
                        button4.Enabled = false;
                    }
                    else if (myArr[n].Equals("B2"))
                    {
                        button5.BackColor = Color.Red; 
                        button5.Enabled = false;
                    }
                    else if (myArr[n].Equals("B3"))
                    {
                        button6.BackColor = Color.Red;
                        button6.Enabled = false;
                    }
                }
            }
            

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
        int i = 0;
        private void button3_Click(object sender, EventArgs e)
        {
            switch (i)
            {
                case 0:
                    i = 1; // change value
                    button3.BackColor = Color.Red; //reserved seat
                    postgres[2] = "A3"; //seat name
                    timi[2] = 8;
                    break;
                case 1:
                    i = 0;
                    button3.BackColor = Color.Green;
                    postgres[2] = "";
                    timi[2] = 0;
                    break;
            }
        }

        int j = 0;
        private void button2_Click(object sender, EventArgs e)
        {
            switch (j)
            {
                case 0:
                    j = 1; // change value
                    button2.BackColor = Color.Red; //reserved seat
                    postgres[1] = "A2"; //seat name
                    timi[1] = 8;
                    break;
                case 1:
                    j = 0;
                    button2.BackColor = Color.Green;
                    postgres[1] = "";
                    timi[1] = 0;
                    break;

            }
        }
        int k = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            switch (k)
            {
                case 0:
                    k = 1; // change value
                    button1.BackColor = Color.Red; //reserved seat
                    postgres[0] = "A1"; //seat name
                    timi[0] = 8;
                    break;
                case 1:
                    k = 0;
                    button1.BackColor = Color.Green;
                    postgres[0] = "";
                    timi[0] = 0;
                    break;
            }
        }
        int p = 0;
        private void button4_Click(object sender, EventArgs e)
        {
            switch (p)
            {
                case 0:
                    p = 1; // change value
                    button4.BackColor = Color.Red; //reserved seat
                    postgres[3] = "B1"; //seat name
                    timi[3] = 8;
                    break;
                case 1:
                    p = 0;
                    button4.BackColor = Color.Green;
                    postgres[3] = "";
                    timi[3] = 0;
                    break;
            }
        }
        int m = 0;
        private void button5_Click(object sender, EventArgs e)
        {
            switch (m)
            {
                case 0:
                    m = 1; // change value
                    button5.BackColor = Color.Red; //reserved seat
                    postgres[4] = "B2"; //seat name
                    timi[4] = 8;
                    break;
                case 1:
                    m = 0;
                    button5.BackColor = Color.Green;
                    postgres[4] = "";
                    timi[4] = 0;
                    break;
            }
        }
        int n = 0;
        private void button6_Click(object sender, EventArgs e)
        {
            switch (n)
            {
                case 0:
                    n = 1; // change value
                    button6.BackColor = Color.Red; //reserved seat
                    postgres[5] = "B3"; //seat name
                    timi[5] = 8;
                    break;
                case 1:
                    n = 0;
                    button6.BackColor = Color.Green;
                    postgres[5] = "";
                    timi[5] = 0;
                    break;

            }
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            
            int cost = timi[0] + timi[1] + timi[2] + timi[3] + timi[4] + timi[5];
            //Console.WriteLine(cost);
            Form6 openForm2 = new Form6(Convert.ToString(cost+ " €"));
            //pass array to next form and define the specific method
            openForm2.showArray(postgres);
            openForm2.Show();
            Visible = false;
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form2 openForm = new Form2();
            openForm.Show();
            Visible = false;
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }
    }
 }
        
    


