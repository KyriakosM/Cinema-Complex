﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema_Complex
{
    public partial class Form6 : Form
    {
        public Form6(string qs)
        {
            InitializeComponent();         
            label4.Text = qs;

            


        }

        //method to show array passed from previous form
        public void showArray(string[] array)
        {
            foreach (string item in array)
            {
                Console.WriteLine("seat "+item);
            }
        }

            private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_Click(object sender,  EventArgs e )
        {

            // assign array from form5 to form6
            //string[] postgres2 = new string[6] ;
            //postgres2 = postgres;
            

            //for (int i = 0; i < 6; i++)
           // {
                //if (!postgres[i].Equals(""))
                //{

                    //Console.WriteLine(postgres[i]);

                    //////write to db
            /*
            conn.Open();
            cmd = new NpgsqlCommand("INSERT INTO seats (position,name) VALUES (@p1,@p2)", conn);
            cmd.Parameters.AddWithValue("p1", "A1");
            cmd.Parameters.AddWithValue( "p2", "kyriakos");
            cmd.ExecuteNonQuery();
            cmd = new NpgsqlCommand("INSERT INTO seats (position,name) VALUES (@p1,@p2)", conn);
            cmd.Parameters.AddWithValue("p1", "A2");
            cmd.Parameters.AddWithValue("p2", "mike");
            cmd.ExecuteNonQuery();
            conn.Close();
            */
            /////
               // }
            //}
            




            ///////////////////////////////
            Form4 openForm = new Form4();
            openForm.Show();
            Visible = false;

        }

        private void label4_Click(object sender, EventArgs e)
        {
                
               

            
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string name = textBox1.Text;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string phone = textBox2.Text;
        }
    }
}
